<script>
  import Nested from './Nested.svelte';
  let name = "Hello World";
</script>
<h1>{name}</h1>
<Nested/>